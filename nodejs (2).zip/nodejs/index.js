const mongoose = require('mongoose');
const express= require('express');
const app=express()
// const OpenAi = require('openai')
const port=5050
const scheduleRoute=require('./route/scheduleroute')
mongoose.connect('mongodb://127.0.0.1:27017/finalproject').then(() => {
    console.log("connected");
}).catch(err => {
    console.log(err);
})
// chat gpt part 
app.use(express.json())
// const openai = new OpenAi({
//     apiKey: "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"
// })
//  app.get("/getResponse", async(req, res) => {
//     const userPrompt=req.body.userPrompt
//     // console.log(userPrompt);
//     const response = await openai.chat.completions.create({
//         model: 'gpt-3.5-turbo',
//         messages: [{ "role": "user", "content": userPrompt }],
//         max_tokens: 3500
//     })
//     // console.log(response.choices[0].message.content);
//     let result= response.choices[0].message.content
//     let results=JSON.parse(result);

// })
// some middlewares before routes
app.use(express.urlencoded({ extended: true }));
app.use(express.json())
// app.use(express.static())
app.use('/schedule',scheduleRoute)
app.listen(port,() => console.log(`app listening on port ${port}!`))
// format this answer with json file with keys 
//old question :   "userPrompt":"basid on this inputs make me a
// schedule for health care routine:my age 50 ,I'm male,i am employee 
//, i work 9 hours everyday,my level of physical activity is sedentary,
//i am  vegen,I am allergic to nuts, i sleep usually 5 hours a day,
//i have a consistent sleep schedule,my stress levels on a scale of 1 to 10 is 9,
//i only drink 3 glasses of water a day ,i spent more than 10 hours on screens,i smoke ? 
//make me a schedule for sunday ,i need more detail with specific hours return the answer
// as a key value pair give the response of each hour in one object as key and value pair
// like this format {sunday:[{7:00 AM:wake up},{7:15 AM:Hydrate with a glass of water}]}"

// basid on this inputs make me a
// schedule for health care routine:my age 50 ,I'm male,i am employee 
// , i work 9 hours everyday,my level of physical activity is sedentary,
// i am  vegen,I am allergic to nuts, i sleep usually 5 hours a day,
// i have a consistent sleep schedule,my stress levels on a scale of 1 to 10 is 9,
// i only drink 3 glasses of water a day ,i spent more than 10 hours on screens,i smoke ? 
// make me a schedule for sunday ,i need more detail with specific hours format this answer with json file
// like this format {dayName: string ,details:{ {hour: number} ,{activity:string}}

