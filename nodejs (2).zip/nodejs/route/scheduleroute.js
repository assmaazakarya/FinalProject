const scheduleController= require('../controller/shcedulecontroller')
const express = require('express');
const route = express.Router();
const OpenAi = require('openai')
const openai = new OpenAi({
    apiKey: "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"
})
// const JWT = require('jsonwebtoken')
// const secret_key="my secret key"
// route.get('/',(req,res)=>{
//     res.send("i am in the user route")
// })

route.post('/addSchedule',async(req, res)=>{
    const {age ,gender,position,work,physical,food,sleep,streetslevel,water,screens,smoke,day}= req.body
    const question =`basid on this inputs make me a schedule for health care routine:my age ${age} 
    ,I'm  ${gender} ,i am  ${position} , i work ${work} hours everyday,my level of physical activity is ${physical},
    i am  ${food}, i sleep usually ${sleep} hours a day,
   ,my stress levels on a scale of 1 to 10 is ${streetslevel},
    i only drink ${water} glasses of water a day ,i spent ${screens} hours on screens,
    i ${smoke}smoke ? make me a schedule for ${day} ,i need more detail in each hour from wake up to sleep and format this answer with json file like this format 
    {dayName: string ,details:{ {hour: number} ,{activity:string},{done:false}`
    const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [{ "role": "user", "content": question }],
        max_tokens: 3550
    })
    let result= response.choices[0].message.content
    let results=JSON.parse(result);
    console.log(results);
    let {dayName,details}=results
    let data= await scheduleController.createOneDaySchedule(dayName,details)
    res.status(200).send('schedule');

})

// route.post('/addSchedule',async(req, res)=>{
//     const userPrompt=req.body.userPrompt
//     // const {age ,gender}= req.body
//     // const question =``
//     const response = await openai.chat.completions.create({
//         model: 'gpt-3.5-turbo',
//         messages: [{ "role": "user", "content": userPrompt }],
//         max_tokens: 3500
//     })
//     let result= response.choices[0].message.content
//     let results=JSON.parse(result);
//     // console.log(results);
//     let {dayName,details}=results
//     let data= await scheduleController.createOneDaySchedule(dayName,details)
//     res.status(200).send('schedule');

// })

// route.post('/inputs',(req,res)=>{
//     let inp=req.body
//     console.log(inp);
    
// })
module.exports=route



// request
// {
//     "userPrompt":"basid on this inputs make me a schedule for health care
// routine:my age 50 ,I'm male,i am employee , i work 9 hours everyday,my level of 
//physical activity is sedentary,i am  vegen,I am allergic to nuts, i sleep usually 5 
//hours a day,i have a consistent sleep schedule,my stress levels on a scale of 1 to 10 is 9,
//i only drink 3 glasses of water a day ,i spent more than 10 hours on screens,i smoke ? 
//make me a schedule for sunday ,i need more detail with specific hours format this answer with 
//json file like this format {dayName: string ,details:{ {hour: number} ,{activity:string}}"
// }